module.exports = {
  content: ["./pages/*.{html,js}", "./index.html", "./js/*.js"],
  theme: {
    extend: {
      colors: {
        // Primary Colors
        primary: "#1A1A1A", // Deep automotive black
        secondary: "#8B7355", // Warm leather brown
        accent: "#C41E3A", // Racing red
        
        // Background Colors
        background: "#FAFAFA", // Clean gallery white
        surface: "#F5F5F5", // Subtle warmth for cards
        
        // Text Colors
        'text-primary': "#2D2D2D", // Strong readability
        'text-secondary': "#6B6B6B", // Supporting information
        
        // Status Colors
        success: "#2D5A27", // Confident green
        warning: "#B8860B", // Amber alert
        error: "#8B2635", // Muted red
        
        // Neutral Scale
        neutral: {
          100: "#F5F5F5", // Light neutral
          200: "#E5E5E5", // Border color
          300: "#D4D4D4", // Medium neutral
          400: "#A3A3A3", // Muted neutral
          500: "#737373", // Mid neutral
          600: "#525252", // Dark neutral
          700: "#404040", // Darker neutral
          800: "#262626", // Very dark neutral
          900: "#171717", // Almost black
        }
      },
      fontFamily: {
        'inter': ['Inter', 'sans-serif'],
        'source-serif': ['Source Serif 4', 'serif'],
        'jetbrains': ['JetBrains Mono', 'monospace'],
        'sans': ['Inter', 'sans-serif'],
        'serif': ['Source Serif 4', 'serif'],
        'mono': ['JetBrains Mono', 'monospace'],
      },
      fontWeight: {
        'normal': '400',
        'medium': '500',
        'semibold': '600',
        'bold': '700',
      },
      boxShadow: {
        'subtle': '0 4px 12px rgba(0, 0, 0, 0.08)',
        'card': '0 2px 8px rgba(0, 0, 0, 0.06)',
        'hover': '0 6px 16px rgba(0, 0, 0, 0.12)',
      },
      borderRadius: {
        'lg': '0.5rem',
        'xl': '0.75rem',
        '2xl': '1rem',
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '128': '32rem',
      },
      transitionDuration: {
        '200': '200ms',
        '300': '300ms',
        '400': '400ms',
      },
      transitionTimingFunction: {
        'out': 'cubic-bezier(0, 0, 0.2, 1)',
      },
      animation: {
        'fade-in': 'fadeIn 400ms ease-out',
        'slide-up': 'slideUp 300ms ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
}